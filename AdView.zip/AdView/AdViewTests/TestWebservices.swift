//
//  TestWebservices.swift
//  AdViewer
//
//  Created by Alex Li Song on 2015-02-14.
//  Copyright (c) 2015 AditMax. All rights reserved.
//
/*
import UIKit
import XCTest
import Foundation
import AdViewer

class TestWebservices: XCTestCase {

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }

    func testExample() {
        // This is an example of a functional test case.
        XCTAssert(true, "Pass")
//        XCTAssertTrue("ttt" == "fs", "")

  /*      request(.GET, "http://aditplanet.com/api/v1/deals/promo", parameters: ["foo": "bar"])
            .responseSwiftyJSON { (request, response, json, error) in
                println(json["data"][0]["terms"])
                println(error)
                //   var item = json["0"] as NSDictionary
                //    println(item)
                var val:String = ""
                //XCTAssertEqual(json["result"],"fs" , "try to access ")
                XCTAssertTrue(json["result"] == "fs", "")
                //XCT
 
        }

    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock() {
            // Put the code you want to measure the time of here.
        }
    }

}*/*/
