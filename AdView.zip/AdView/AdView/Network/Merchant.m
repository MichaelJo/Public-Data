//
//  Merchant.m
//  AdViewer
//
//  Created by Alex Li Song on 2015-03-09.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import "Merchant.h"


@implementation Merchant

@dynamic category;
@dynamic facebook;
@dynamic featured;
@dynamic featured_end_date;
@dynamic id;
@dynamic images;
@dynamic map_coordinates;
@dynamic name;
@dynamic sub_description;
@dynamic syncStatus;
@dynamic terms;
@dynamic twitter;
@dynamic updatedAt;
@dynamic www;
@dynamic localImageFiles;

@end
