//
//  Promo.m
//  AdViewer
//
//  Created by Alex Li Song on 2015-03-01.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import "Promo.h"


@implementation Promo

@dynamic syncStatus;
@dynamic adpoints;
@dynamic category;
@dynamic deal_price_note;
@dynamic hot_deal;
@dynamic id;
@dynamic images;
@dynamic initial_price_note;
@dynamic location;
@dynamic merchant_id;
@dynamic name;
@dynamic subtitle;
@dynamic terms;
@dynamic end_date;
@dynamic hot_end;
@dynamic hot_start;
@dynamic start_date;
@dynamic updatedAt;
@dynamic valit_end;
@dynamic valit_start;

@end
