//
//  TopCategory.m
//  AdViewer
//
//  Created by Alex Li Song on 2015-03-02.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import "TopCategory.h"


@implementation TopCategory

@dynamic syncStatus;
@dynamic id;
@dynamic images;
@dynamic name;
@dynamic updatedAt;

@end
