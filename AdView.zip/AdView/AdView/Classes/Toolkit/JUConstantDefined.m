//
//  JUConstantDefined.m
//  
//
//  Created by Alex Song on 15-1-1.
//  Copyright (c) 2015 Aditmax. All rights reserved.
//


NSString *const kkkk = @"";
