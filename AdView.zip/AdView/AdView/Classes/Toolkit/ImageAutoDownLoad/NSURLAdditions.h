//
//  NSURLAdditions.h
//  letao
//
//  Created by wangchen on 11-7-25.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSURL(Additions)

+ (BOOL)isWebURL:(NSURL*)URL;

@end
