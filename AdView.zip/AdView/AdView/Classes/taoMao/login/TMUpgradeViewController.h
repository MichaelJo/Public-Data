//
//  TMUpgradeViewController.h
//  weimao
//
//  Created by Alex Song on 14-4-28.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import "LTKViewController.h"

@interface TMUpgradeViewController : LTKViewController<UITextFieldDelegate>
{
    UIView *view_bar;
    UITextField *fieldName,*fieldPsw,*filedYAO;
}
@end
