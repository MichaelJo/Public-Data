//
//  FCaboutUsViewController.h
//  FCset
//
//  Created by Skyler on 13-6-24.
//  Copyright (c) 2013年 SK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FCaboutUsViewController : LTKViewController

@end
