//
//  ContentViewController.h
//  FragmentsTabsPager
//
//  Created by nakajijapan on 11/28/14.
//  Copyright (c) 2015 net.nakajijapan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContentViewController : UIViewController
@property (weak) IBOutlet UILabel *label;
//@property (weak) IBOutlet UILabel *labelTitle;

@property NSString *textLabel;
//@property NSString *textLabelTitle;

@end
