//
//  AdPagerViewController.h
//  AdViewer
//
//  Created by Alex Li Song on 2015-03-07.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NKJPagerViewController.h"
@interface AdPagerViewController : NKJPagerViewController

@end

