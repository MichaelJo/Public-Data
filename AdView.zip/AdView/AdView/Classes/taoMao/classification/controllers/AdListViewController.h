//
//  AdListViewController.h
//  AdViewer
//
//  Created by Alex Li Song on 2015-03-07.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AdListViewController : UIViewController
@property (weak) IBOutlet UILabel *label;
//@property (weak) IBOutlet UILabel *labelTitle;

@property NSString *textLabel;
//@property NSString *textLabelTitle;

@end