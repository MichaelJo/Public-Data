//
//  FCShoppingCell.h
//  Flower&Cake
//
//  Created by 123 on 13-8-13.

//

#import <UIKit/UIKit.h>

@interface FCShoppingCell : UITableViewCell
@property(assign,nonatomic)BOOL isTouch;
@end
