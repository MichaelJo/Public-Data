//
//  TMAccountWINViewController.h
//  TaoMao
//
//  Created by Alex Song on 14-4-23.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import "LTKViewController.h"

@interface TMAccountWINViewController : LTKViewController
{
    UIView *view_bar;
     UITextField *fieldXM,*fieldSJ,*fieldYB,*fieldDQ,*fieldJD;

}
@end
