//
//  StoreTableCell.m
//  AdViewer
//
//  Created by Alex Li Song on 2015-03-29.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import "StoreTableCell.h"

@implementation StoreTableCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
