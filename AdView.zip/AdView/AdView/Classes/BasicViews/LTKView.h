//
//  LTKView.h
//  LvTongKa
//
//  Created by 123 on 13-8-26.

//

#import <UIKit/UIKit.h>

@interface LTKView : UIView

@end
