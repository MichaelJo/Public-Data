//
//  AdPreferences.m
//  AdViewer
//
//  Created by Alex Li Song on 2015-03-04.
//  Copyright (c) 2015 AditMax. All rights reserved.
//

#import "AdPreferences.h"

@implementation AdPreferences

@dynamic hasSeenIntro;
@dynamic pressCount;
@dynamic name;
@dynamic cartItemIdArray;
@dynamic cartItemDealIdArray;
@dynamic cartItemQuantityArray;
@dynamic clientId;
@dynamic sessionId;
@dynamic cartId;
@dynamic cartGrandTotal;
@dynamic cartItemAdpointsArray;
@dynamic popProductIdArray;
//@dynamic newProductIdArray;
@dynamic superProductIdArray;

@end