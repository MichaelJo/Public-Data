//
//  junk.m
//  AdView
//
//  Created by DavidWu on 2014-09-23.
//  Copyright (c) 2014 AditMax. All rights reserved.
//

#import <Foundation/Foundation.h>
