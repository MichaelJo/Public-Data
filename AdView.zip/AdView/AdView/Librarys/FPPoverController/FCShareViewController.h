//
//  JURoomViewController.h
//  
//
//  Copyright (c) 2015 Aditmax. All rights reserved.
//


@interface FCShareViewController : LTKViewController<UITableViewDataSource,UITableViewDelegate>
{
    
    UITableView *_tableView;
    NSArray *arr_name;
    int _height;
}


@end
